<?php get_header(); ?>

				<!-- featured article -->
		        <div class="topbar"> </div>
       			<!-- featured article -->

	       			<!-- .main_content-->
	                <div class="main_content">

		       			<!-- section content -->
			            <section class="content">

				            <!-- standart article -->
				            <article>

								<h2><?php _e('404 Not Found','site5framework') ?></h2>

		                        	<div class="entry-content clearfix">
		                        	<div class="entry-colors"><div class="color_col_1"></div><div class="color_col_2"></div><div class="color_col_3"></div></div>

										<p style="text-align:center;"><?php _e("The article you were looking for was not found, but maybe try looking again!", "site5framework"); ?></p>
									</div>
							</article>
						</section>
						<?php get_sidebar(); ?>
					</div>


<?php get_footer(); ?>