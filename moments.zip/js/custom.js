jQuery(function($) {

	$(document).ready(function(){

		/*FIT VIDEOS STARTS*/
	    jQuery("article").fitVids();
	    /*FIT VIDEOS ENDS*/


	    /*PRETTYPHOTO STARTS*/
	    jQuery("a[class^='prettyPhoto']").prettyPhoto();
	    /*PRETTYPHOTO ENDS*/

	});

});